<?php
include_once '../config.php';
include_once '../functions.php';
session_start();
//verifier si l'admin est deja connecté
if (!isset($_SESSION['admin_loggedin'])) {
    header('Location: login.php');
    exit;
}
$pdo = pdo_connect_mysql();
?>
