<?php
include 'main.php';
// Valeurs de ticket d’entrée par défaut
$category = array(
    'id' => '',
    'name' => ''
);
if (isset($_GET['id'])) {
    // Obtenir la catégorie dans la base de données
    $stmt = $pdo->prepare('SELECT * FROM categories WHERE id = ?');
    $stmt->execute([ $_GET['id'] ]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    //initalise le param ID, modifier une catégorie existante
    $page = 'Edit';
    if (isset($_POST['submit'])) {
        // Mettre à jour la catégorie
        $stmt = $pdo->prepare('UPDATE categories SET name = ? WHERE id = ?');
        $stmt->execute([ $_POST['name'], $_GET['id'] ]);
        header('Location: categories.php');
        exit;
    }
    if (isset($_POST['delete'])) {
        // Mettre à jour la catégorie
        $stmt = $pdo->prepare('DELETE FROM categories WHERE id = ?');
        $stmt->execute([ $_GET['id'] ]);
        header('Location: categories.php');
        exit;
    }
} else {
    // Créer une nouvelle catégorie
    $page = 'Create';
    if (isset($_POST['submit'])) {
        $stmt = $pdo->prepare('INSERT INTO categories (name) VALUES (?)');
        $stmt->execute([ $_POST['name'] ]);
        header('Location: categories.php');
        exit;
    }
}
?>

<?=template_admin_header($page . ' Category')?>

<h2><?=$page?> Categories</h2>

<div class="content-block">
    <form action="" method="post" class="form responsive-width-100">
        <label for="name">Nom</label>
        <input type="text" id="name" name="name" placeholder="Nom" value="<?=$category['name']?>" required>
        <div class="submit-btns">
            <input type="submit" name="submit" value="Valider">
            <?php if ($page == 'Edit'): ?>
            <input type="submit" name="delete" value="Supprimer" class="delete">
            <?php endif; ?>
        </div>
    </form>
</div>

<?=template_admin_footer()?>
