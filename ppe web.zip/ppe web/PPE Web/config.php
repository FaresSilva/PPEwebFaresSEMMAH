<?php
ini_set('display_errors', 'off');
// nom d’hôte de la base de données, vous n’avez généralement pas besoin de la modifier 
define('db_host', 'localhost');
// nom d'utilisateur sur la database
define('db_user', 'root');
// mot de passe sur la database
define('db_pass', '');
// nom sur la database
define('db_name', 'ppe3');
// database charset(liste de caractères), modifier uniquement si utf8 n’est pas pris en charge par votre langue
define('db_charset', 'utf8');
// 
define('mail_from', 'giovanniberg67270@gmail.com');
// Voir le lien des tickets, cela sera utilisé pour les emails des tickets
define('view_ticket_link', 'http://localhost/ticketsystem/view.php');
?>
