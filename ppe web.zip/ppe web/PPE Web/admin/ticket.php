<script>
function warning() {
  alert('Cet action est irreversible');
}
</script>

<?php

include '../config.php';
include '../functions.php';
$pdo = pdo_connect_mysql();
// Valeurs par défaut des tickets d'entrée
$ticket = array(
    'title' => '',
    'msg' => '',
    'email' => '',
    'created' => date('Y-m-d\TH:i:s'),
    'status' => 'open',
    'priority' => 'Bas',
    'category_id' => 1,
    'private' => 0
);
// Récupérez tous les noms de catégories de la table des catégories MySQL
$categories = $pdo->query('SELECT * FROM categories')->fetchAll(PDO::FETCH_ASSOC);
$status = array('ouvert', 'ferme', 'resolu');
$priority = array('Bas', 'Moyen', 'Haut');

if (isset($_GET['id'])) {
    // Obtenir le ticket dans la base de données
    $stmt = $pdo->prepare('SELECT * FROM tickets WHERE id = ?');
    $stmt->execute([ $_GET['id'] ]);
    $ticket = $stmt->fetch(PDO::FETCH_ASSOC);
    // Iniatilastion de l'ID, modifier un billet existant
    $page = 'Edit';
    if (isset($_POST['submit'])) {
        //Mettre à jour le ticket
        $stmt = $pdo->prepare('UPDATE tickets SET status = ? WHERE id = ?');
        $stmt->execute([ $_POST['status'], $_GET['id'] ]);
        header('Location: index.php');
    }
    if (isset($_POST['delete'])) {
        // Supprimer le ticket 
        $stmt = $pdo->prepare('DELETE FROM tickets WHERE id = ?');
        $stmt->execute([ $_GET['id'] ]);
        header('Location: index.php');
    }
}
?>

<?=template_admin_header($page . ' Ticket')?>

<h2><?=$page?> Ticket</h2>

<div class="content-block">
    <form action="" method="post" name="ticketform" class="form responsive-width-100">
        <label for="title">Titre</label>
        <input type="text" id="title" name="title" placeholder="Titre" value="<?=$ticket['title']?>" disabled="disabled">
        <label for="msg">Message</label>
        <textarea id="msg" name="msg" placeholder="Entrer votre Message..." disabled="disabled"><?=$ticket['msg']?></textarea>
        <label for="email">Email</label>
        <input type="text" id="email" name="email" placeholder="Email" value="<?=$ticket['email']?>" disabled="disabled">
        <label for="status">Statut</label>
        <select id="status" name="status" style="margin-bottom: 30px;">
            <?php foreach ($status as $s): ?>
            <option value="<?=$s?>"<?=$s==$ticket['status']?' selected':''?>><?=$s?></option>
            <?php endforeach; ?>
        </select>
        <div class="submit-btns">
            <input type="submit" name="submit" value="Valider" >
            <?php if ($page == 'Edit'): ?>
            <input type="submit" name="delete" value="Supprimer" class="delete" onclick="warning()">
            <?php endif; ?>
        </div>
    </form>
</div>

<?=template_admin_footer()?>
