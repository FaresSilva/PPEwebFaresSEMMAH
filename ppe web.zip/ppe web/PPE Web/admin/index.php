<?php
include 'main.php';
$stmt = $pdo->prepare('SELECT t.*, c.name AS category FROM tickets t LEFT JOIN categories c ON c.id = t.category_id WHERE t.status = "ouvert" ORDER BY t.priority DESC, t.created DESC');
$stmt->execute();
$open_tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt = $pdo->prepare('SELECT t.*, c.name AS category FROM tickets t LEFT JOIN categories c ON c.id = t.category_id WHERE t.status = "resolu" ORDER BY t.priority DESC, t.created DESC');
$stmt->execute();
$resolved_tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stmt = $pdo->prepare('SELECT t.*, c.name AS category FROM tickets t LEFT JOIN categories c ON c.id = t.category_id WHERE t.status = "ferme" ORDER BY t.priority DESC, t.created DESC');
$stmt->execute();
$closed_tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?=template_admin_header('Tickets')?>

<h2>Tickets Ouvert (<?=number_format(count($open_tickets))?>)</h2>


<div class="content-block">
    <div class="table">
        <table>
            <thead>
                <tr>
                    <td>Titre</td>
                    <td class="responsive-hidden">Message</td>
                    <td class="responsive-hidden">Email</td>
                    <td class="responsive-hidden">Creation</td>
                    <td class="responsive-hidden">Categories</td>
                    <td class="responsive-hidden">Priorité</td>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($open_tickets)): ?>
                <tr>
                    <td colspan="8" style="text-align:center;">Aucun Tickets Ouvert</td>
                </tr>
                <?php else: ?>
                <?php foreach ($open_tickets as $ticket): ?>
                <tr class="details" onclick="location.href='ticket.php?id=<?=$ticket['id']?>'">
                    <td style="word-break:break-all;"><?=$ticket['title']?></td>
                    <td class="responsive-hidden">
                        <div style="overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:300px;"><?=$ticket['msg']?></div>
                    </td>
                    <td class="responsive-hidden"><?=$ticket['email']?></td>
                    <td class="responsive-hidden"><?=$ticket['created']?></td>
                    <td class="responsive-hidden"><?=$ticket['category']?></td>
                    <td class="responsive-hidden"><?=$ticket['priority']?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<h2 style="padding-top:30px;">Tickets Résolu(<?=number_format(count($resolved_tickets))?>)</h2>

<div class="content-block">
    <div class="table">
        <table>
            <thead>
                <tr>
                    <td>Titre</td>
                    <td class="responsive-hidden">Message</td>
                    <td class="responsive-hidden">Email</td>
                    <td class="responsive-hidden">Creation</td>
                    <td class="responsive-hidden">Categories</td>
                    <td class="responsive-hidden">Priorité</td>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($resolved_tickets)): ?>
                <tr>
                    <td colspan="8" style="text-align:center;">Aucun Tickets Résolu</td>
                </tr>
                <?php else: ?>
                <?php foreach ($resolved_tickets as $ticket): ?>
                <tr class="details" onclick="location.href='ticket.php?id=<?=$ticket['id']?>'">
                    <td><?=$ticket['title']?></td>
                    <td class="responsive-hidden">
                        <div style="overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:300px;"><?=$ticket['msg']?></div>
                    </td>
                    <td class="responsive-hidden"><?=$ticket['email']?></td>
                    <td class="responsive-hidden"><?=$ticket['created']?></td>
                    <td class="responsive-hidden"><?=$ticket['category']?></td>
                    <td class="responsive-hidden"><?=$ticket['priority']?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<h2 style="padding-top:30px;">Tickets Fermé (<?=number_format(count($closed_tickets))?>)</h2>

<div class="content-block">
    <div class="table">
        <table>
            <thead>
                <tr>
                    <td>Titre</td>
                    <td class="responsive-hidden">Message</td>
                    <td class="responsive-hidden">Email</td>
                    <td class="responsive-hidden">Creation</td>
                    <td class="responsive-hidden">Categories</td>
                    <td class="responsive-hidden">Priorité</td>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($closed_tickets)): ?>
                <tr>
                    <td colspan="8" style="text-align:center;">Aucun Tickets Fermé</td>
                </tr>
                <?php else: ?>
                <?php foreach ($closed_tickets as $ticket): ?>
                <tr class="details" onclick="location.href='ticket.php?id=<?=$ticket['id']?>'">
                    <td><?=$ticket['title']?></td>
                    <td class="responsive-hidden">
                        <div style="overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:300px;"><?=$ticket['msg']?></div>
                    </td>
                    <td class="responsive-hidden"><?=$ticket['email']?></td>
                    <td class="responsive-hidden"><?=$ticket['created']?></td>
                    <td class="responsive-hidden"><?=$ticket['category']?></td>
                    <td class="responsive-hidden"><?=$ticket['priority']?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?=template_admin_footer()?>
