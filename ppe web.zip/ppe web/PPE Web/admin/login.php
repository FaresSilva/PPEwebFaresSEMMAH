<?php
session_start();
include_once '../config.php';
include_once '../functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
if (isset($_POST['admin_username'], $_POST['admin_password'])) {
    $stmt = $pdo->prepare('SELECT * FROM admin_accounts WHERE username = ? AND password = ?');
    $stmt->execute([ $_POST['admin_username'], $_POST['admin_password'] ]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($account) {
        $_SESSION['admin_loggedin'] = true;
        $_SESSION['admin_id'] = $account['id'];
        header('Location: index.php');
        exit;
    } else {
        $msg = 'Identifiant / Mot de Passe Incorect';
    }
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Connexion Admin</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,minimum-scale=1">
        <link href="admin.css" rel="stylesheet" type="text/css">
	</head>
	<body class="login">
        <form action="" method="post" class="">
            <input type="text" name="admin_username" placeholder="Identifiant" required>
            <input type="password" name="admin_password" placeholder="Mot de Passe">
            <input type="submit" value="Connexion">
            <p><?=$msg?></p>
        </form>
    </body>
</html>
